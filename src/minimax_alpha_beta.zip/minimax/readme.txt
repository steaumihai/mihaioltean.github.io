data are read from .txt files having the following structure:

on the first line is the number of nodes
on each other line we have a node with additional info. There are 2 cases here:
a. if the node is an internal node, we have: node_index num_children index_children1 index_children2 ...
b. if the node is a leaf, we have: node_index 0 score

nodes are indexed from 0 starting with the root of the tree and then are traversed on levels.


test data:

tree1.txt - last example from ppt slides.
tree2.txt - x-0 example from ppt slides
tree3.txt - wikipedia example https://en.wikipedia.org/wiki/Alpha-beta_pruning (accessed on 2015.03.22)
tree4.txt - https://www.youtube.com/watch?v=xBXHtz4Gbdo
tree5.txt - https://www.youtube.com/watch?v=Ewh-rF7KSEg
tree6.txt - http://thundaxsoftware.blogspot.ro/2010/11/alpha-beta-pruning-algorithm-with.html - first image
tree7.txt - http://cs.ucla.edu/~rosen/161/notes/alphabeta.html