
// minimax with alpha-beta cuttofs

// compiled with Visual Studio 2013 Express Edition

// MIT licence ... you may do whatever you want with this source code
// version 2015.03.29

// questions at: mihai.oltean@gmail.com
// http://www.tcreate.org


#include <stdio.h>
#include <stdlib.h>

#define infinity 10000

//-------------------------------------------------------------------------
struct node{
	int score;         // score for leaves
	int num_children;  // number of children
	int *children;     // index of children 
};

//-------------------------------------------------------------------------
bool read_tree(char *filename, node*& tree, int &num_nodes)
{
	// each node has an index.
	// root has index 0
	// the indexes of other nodes are obtained by traversing the tree level by level.

	// file structure: on each line we have information about one node:
	// node_index num_children
	// if num_children is 0 then the next value is the score of that leaf
	// if num_children > 0 then we have a list of indexes for each children

	FILE *f = fopen(filename, "r"); // full path to the input file
	if (!f)
		return false;

	fscanf(f, "%d", &num_nodes);
	tree = (node*)malloc(num_nodes * sizeof(node));

	for (int i = 0; i < num_nodes; i++){
		int node_index;
		fscanf(f, "%d", &node_index);
		fscanf(f, "%d", &tree[node_index].num_children);

		if (!tree[node_index].num_children){
			fscanf(f, "%d", &tree[node_index].score);
			tree[node_index].children = NULL;
		}
		else{
			tree[node_index].children = (int*)malloc (tree[node_index].num_children * sizeof(int));
			tree[node_index].score = 0; // it is not used anyway
			for (int j = 0; j < tree[node_index].num_children; j++)
				fscanf(f, "%d", &tree[node_index].children[j]);
		}
	}
	return true;
}
//-------------------------------------------------------------------------
int minimax_ab(node* tree, int node_index, int level, int a, int b, int *visited, int &num_visited)
{
	if (!tree[node_index].num_children){
		visited[num_visited++] = node_index;
		printf("%c leaf - score = %d\n", node_index + 65, tree[node_index].score);
		return tree[node_index].score;
	}
	else
		if (level % 2){// min level
			int min_score = infinity;
			visited[num_visited++] = node_index;

			for (int i = 0; i < tree[node_index].num_children; i++){
				printf("%c %d %d\n", node_index + 65, a, b);
				int child_score = minimax_ab(tree, tree[node_index].children[i], level + 1, a, b, visited, num_visited);
				if (min_score > child_score)
					min_score = child_score;
				if (b > min_score)
					b = min_score;
				printf("%c %d %d\n", node_index + 65, a, b);
				if (b <= a){
					printf("stop exploring the children of %c\n", node_index + 65);
					break;
				}
			}
			return b;
			//return min_score;
		}
		else{// max level;
			int max_score = -infinity;
			visited[num_visited++] = node_index;
			for (int i = 0; i < tree[node_index].num_children; i++){
				printf("%c %d %d\n", node_index + 65, a, b);
				int child_score = minimax_ab(tree, tree[node_index].children[i], level + 1, a, b, visited, num_visited);
				if (max_score < child_score)
					max_score = child_score;
				if (a < max_score)
					a = max_score;
				printf("%c %d %d\n", node_index + 65, a, b);
				if (b <= a){
					printf("stop exploring the children of %c\n", node_index + 65);
						break;
				}
			}
			return a;
			//return max_score;
		}
}
//-------------------------------------------------------------------------
int main(void)
{
	int num_nodes;
	node *tree;

	if (read_tree("e4.txt", tree, num_nodes)){

		int a = -infinity;
		int b = infinity;

		int *visited = (int*)malloc (num_nodes * sizeof(int));
		int num_visited = 0;

		int alpha = minimax_ab(tree, 0, 0, a, b, visited, num_visited);

		printf("Alpha = %d\n", alpha);

		printf("Number of visited nodes = %d\n", num_visited);
		printf("Visited nodes: ");
		for (int i = 0; i < num_visited; i++)
			printf("%d ", visited[i]);

		// compute the unvisited nodes
		bool *is_visited = (bool*)malloc(num_nodes * sizeof(bool));
		for (int i = 0; i < num_nodes; is_visited[i++] = false);
		for (int i = 0; i < num_visited; is_visited[visited[i++]] = true);

		printf("\nUnvisited nodes: ");
		for (int i = 0; i < num_nodes; i++)
			if (!is_visited[i])
			  printf("%c ", i + 65);

		free(visited);
		free(is_visited);

// free memory
		for (int i = 0; i < num_nodes; i++)
			if (tree[i].children)
			  free(tree[i].children);
		free(tree);
	}
	else
		printf("Cannot read/find input file! Please place it in a folder where I can find it!");

	printf("\n\nPress enter.");
	getchar();

	return 0;
}
//-------------------------------------------------------------------------