//---------------------------------------------------------------------------
//   Traceless Genetic Programming Software
//   Copyright (C) 2004, Mihai Oltean  (moltean@nessie.cs.ubbcluj.ro)
//   beta version 0.1
//   last changed  17.05.2004

//   Compiled with Borland C++ 5.5, free compiler, from www.borland.com.
//   Also compiled with g++, bc++3.1 and vc++ 6.0.

//   This program is a free software.
//   It may be redistributed and/or modified but it may not be sold.

//   This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY.

//   Any new version of this program will be available at  www.tgp.cs.ubbcluj.ro

//   Please reports any sugestions and/or bugs to       moltean@nessie.cs.ubbcluj.ro

//   Training data file must have the following format (see even_5.txt):

//   m n
//   x11 x12 ... x1n f1
//   x21 x22 ....x2n f2
//   .............
//   xm1 xm2 ... xmn fm

//   where m is the number of training data
//   and n is the number of variables.

//---------------------------------------------------------------------------
//                         ATTENTION:
//  This program has been used for evolving Boolean functions.
//  Only Binary inputs are used.
//  If you want other types please modify the data types.
//  "even_5.txt" file contains the set of fitness cases for the even-5-parity problem.
//---------------------------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <math.h>

//#include <vcl.h>

#define NumberOfOperators 4

// + -1
// - -2
// * -3
// / -4

typedef struct{
          char *inf;        // a string of genes
          int fit;          // the fitness
        } Chromosome;

typedef Chromosome* Population;

Population old_pop, new_pop;

char **x;                  // training data
char *target;              // target values

int NumberOfTrainingData;
int NumberOfVariables;

double pm;                   // mutation probability
double pcross;               // crossover probability
int CodeLength;              // the number of genes
int PopSize;                 // the number of individuals in population  (must be an odd number!!!)
int NumberOfGenerations;     // the number of generations

//---------------------------------------------------------------------------
void AlocateData(void)
{
  target = new char[NumberOfTrainingData];
  x = new char*[NumberOfTrainingData];
  for (int i = 0; i < NumberOfTrainingData; i++)
    x[i] = new char[NumberOfVariables];
}
//---------------------------------------------------------------------------
void ReadTrainingData(void)
{
  FILE* f_in;
  int d;
  f_in = fopen("even_5.txt", "r");
  fscanf(f_in, "%d%d", &NumberOfTrainingData, &NumberOfVariables);
  AlocateData();
  for (int i = 0; i < NumberOfTrainingData; i++){
    for (int j = 0; j < NumberOfVariables; j++){

      fscanf(f_in, "%d", &d);
      x[i][j] = (char)d;
    }
    fscanf(f_in, "%d", &d);
    target[i] = (char)d;
  }
  fclose(f_in);
}
//---------------------------------------------------------------------------
void AlocatePopulation(void)
{
  old_pop = new Chromosome[PopSize];
  new_pop = new Chromosome[PopSize];

  for (int i = 0; i < PopSize; i++){
    old_pop[i].inf = new char[NumberOfTrainingData];
    new_pop[i].inf = new char[NumberOfTrainingData];
  }
}
//---------------------------------------------------------------------------
void CopyIndividual(const Chromosome& Source, Chromosome& Dest)
{
  for (int i = 0; i < NumberOfTrainingData; i++)
    Dest.inf[i] = Source.inf[i];
  Dest.fit = Source.fit;
}
//---------------------------------------------------------------------------
void Init(void) // randomly initializes the individuals
{
  for (int k = 0; k < PopSize; k++){
    old_pop[k].fit = 0;
    int rv = rand() % NumberOfVariables;
    for (int i = 0; i < NumberOfTrainingData; i++){
      old_pop[k].inf[i] = x[i][rv];
      old_pop[k].fit += abs(old_pop[k].inf[i] - target[i]);
    }
  }
}
//---------------------------------------------------------------------------
void Fitness(Chromosome &c)
{
  c.fit = 0;
  for (int i = 0; i < NumberOfTrainingData; i++)
    c.fit += abs(c.inf[i] - target[i]);
}
//---------------------------------------------------------------------------
int sort_function(const void *a, const void *b)
{
  if (((Chromosome *)a)->fit > ((Chromosome *)b)->fit)
    return 1;
  else
    if (((Chromosome *)a)->fit < ((Chromosome *)b)->fit)
      return -1;
    else
      return 0;
}
//---------------------------------------------------------------------------
void SortByFitness(void) // sort ascending the individuals in population
{
  qsort((void *)old_pop, PopSize, sizeof(old_pop[0]), sort_function);
}
//---------------------------------------------------------------------------
void DezalocatePopulation(void)
{
  for (int i = 0; i < PopSize; i++){
    delete[] old_pop[i].inf;
    delete[] new_pop[i].inf;
  }
  delete[] old_pop;
  delete[] new_pop;
}
//---------------------------------------------------------------------------
void DezalocateData(void)
{
  for (int i = 0; i < NumberOfTrainingData; i++)
    delete[] x[i];
  delete[] x;
  delete[] target;
}
//---------------------------------------------------------------------------
int Selection(int TS)   // tournament selection; TS is the tournament size
{
  int r = rand() % PopSize;
  for (int i = 1; i < TS; i++){
    int t = rand() % PopSize;
    if (old_pop[t].fit < old_pop[r].fit)
      r = t;
  }
  return r;
}
//---------------------------------------------------------------------------
int main(void)
{
  FILE *fout = fopen("out5.txt", "w");
  double pinsert      = 0.05;
  pcross              = 1;

  PopSize             = 500;
  NumberOfGenerations = 1000;
  int p1, p2, i;
  double ps;
  int TS = 2;

  ReadTrainingData();

  Chromosome offspring1, offspring2;
  offspring1.inf = new char[NumberOfTrainingData];
  offspring2.inf = new char[NumberOfTrainingData];

  AlocatePopulation();
  fprintf(fout, "%d %d\n", PopSize, NumberOfGenerations);

  int succ_rate = 0;                             // if you want to analize the success rate
  for (int runs = 0; runs < 100; runs ++){       // please uncomment these lines
    srand(runs);
    printf( "[RUN %d SUCCESS RATE %d]\n", runs, succ_rate);
    Init();

    SortByFitness();

    for (int g = 0; g < NumberOfGenerations; g++){

      int new_pop_size = 1;
      CopyIndividual(old_pop[0], new_pop[0]);  // eltism; the best individual is copied in the next generation

      if (g % 100 == 0)  // print step = 100
        printf("Generation %d Fitness %d\n", g, old_pop[0].fit);

      while (new_pop_size < PopSize){
        double p = rand() / (double)RAND_MAX;

        if (p < pinsert){                     // insertion
          new_pop[new_pop_size].fit = 0;
          int rv = rand() % NumberOfVariables;
	  for (i = 0; i < NumberOfTrainingData; i++){
            new_pop[new_pop_size].inf[i] = x[i][rv];
            new_pop[new_pop_size].fit += abs(new_pop[new_pop_size].inf[i] - target[i]);
          }
          new_pop_size++;
        }
        else{                             // recombination
          // first we have to choose an operator
          int op = rand() % NumberOfOperators;
          switch (op){
            case 0: //         AND Gate
              p1 = Selection(TS);
              p2 = Selection(TS);
              ps = rand() / (double) RAND_MAX;
              if (ps <= pcross){  // if crossover make crossover
                new_pop[new_pop_size].fit = 0;
                for (i = 0; i < NumberOfTrainingData; i++){
                  new_pop[new_pop_size].inf[i] = old_pop[p1].inf[i] && old_pop[p2].inf[i];   // the operator AND
                  new_pop[new_pop_size].fit += abs(new_pop[new_pop_size].inf[i] - target[i]);
                }
                new_pop_size++;
              }
              else{
                //  otherwise copy the parents in the new population
                CopyIndividual(old_pop[p1], new_pop[new_pop_size]);
                new_pop_size++;
                if (new_pop_size < PopSize){
                  CopyIndividual(old_pop[p2], new_pop[new_pop_size]);
                  new_pop_size++;
                }
              }
              break;

            case 1:             // OR gate
              p1 = Selection(TS);
              p2 = Selection(TS);
              ps = rand() / (double) RAND_MAX;
              if (ps <= pcross){
                new_pop[new_pop_size].fit = 0;
                for (i = 0; i < NumberOfTrainingData; i++){
                  new_pop[new_pop_size].inf[i] = old_pop[p1].inf[i] || old_pop[p2].inf[i];
                  new_pop[new_pop_size].fit += abs(new_pop[new_pop_size].inf[i] - target[i]);
                }
                new_pop_size++;
              }
              else{
                CopyIndividual(old_pop[p1], new_pop[new_pop_size]);
                new_pop_size++;
                if (new_pop_size < PopSize){
                  CopyIndividual(old_pop[p2], new_pop[new_pop_size]);
                  new_pop_size++;
                }
              }
              break;
            case 2: // NAND gate
              p1 = Selection(TS);
              p2 = Selection(TS);
              ps = rand() / (double) RAND_MAX;
              if (ps <= pcross){
                new_pop[new_pop_size].fit = 0;
                for (i = 0; i < NumberOfTrainingData; i++){
                  new_pop[new_pop_size].inf[i] = !(old_pop[p1].inf[i] && old_pop[p2].inf[i]);
                  new_pop[new_pop_size].fit += abs(new_pop[new_pop_size].inf[i] - target[i]);
                }
                new_pop_size++;
              }
              else{
                CopyIndividual(old_pop[p1], new_pop[new_pop_size]);
                new_pop_size++;
                if (new_pop_size < PopSize){
                  CopyIndividual(old_pop[p2], new_pop[new_pop_size]);
                  new_pop_size++;
                }
              }
              break;
            case 3: // NOR gate
              p1 = Selection(TS);
              p2 = Selection(TS);
              ps = rand() / (double) RAND_MAX;
              if (ps <= pcross){
                new_pop[new_pop_size].fit = 0;
                for (i = 0; i < NumberOfTrainingData; i++){
                  new_pop[new_pop_size].inf[i] = !(old_pop[p1].inf[i] || old_pop[p2].inf[i]);
                  new_pop[new_pop_size].fit += abs(new_pop[new_pop_size].inf[i] - target[i]);
                }
                new_pop_size++;
              }
              else{
                CopyIndividual(old_pop[p1], new_pop[new_pop_size]);
                new_pop_size++;
                if (new_pop_size < PopSize){
                  CopyIndividual(old_pop[p2], new_pop[new_pop_size]);
                  new_pop_size++;
                }
              }
              break;


            }// switch
          }
      }
      for (int k = 0; k < PopSize; k++)   // copy from intermediate population to the new population
        CopyIndividual(new_pop[k], old_pop[k]);
      SortByFitness();
      if (old_pop[0].fit == 0){
        fprintf(fout, "%d\n", g);     // prints the generation where the fitness gets 0
        break;
      }
    }
    fprintf(fout, "%d\n", NumberOfGenerations + 1);    // otherwise prints the unsuccess
    if (old_pop[0].fit == 0){         // if you want to analize the success rate
      succ_rate++;                    // please uncomment these lines
    }

    printf("Fitness %d\n", old_pop[0].fit);
  }                                                    // if you want to analize the success rate
  printf("Success rate %d\n", succ_rate);              // please uncomment these lines
  fprintf(fout, "Success rate %d\n", succ_rate);              // please uncomment these lines


  DezalocatePopulation();

  delete[] offspring1.inf;
  delete[] offspring2.inf;

  DezalocateData();
  fclose(fout);
  printf("Press any key...");
  getchar();
  return 0;
}
//---------------------------------------------------------------------------
